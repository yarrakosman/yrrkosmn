﻿
using AzureFunctions.Autofac;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage;
using DailyTasks.Shared.Storage.Models;
using ECR.Core.CrmService;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Web;
using ECR.Enforcement;
using Microsoft.Xrm.Sdk.Query;

namespace DailyTasks.EnforcementSchedule.EnsureSchedules
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityRead
    {
        private static DataContractSerializer lateBoundSerializer = new DataContractSerializer(typeof(EnsureSchedulesEntities));


        [FunctionName("EnsureSchedules-Read")]
        public static async Task<int> EnsureSchedulesRead(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            ILogger log,
            [Inject] ICRMConnection crmConnection,
            [Inject] IStorageOperations storageOperations,
            [Inject] IConfig config)
        {
            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedules - Activity - Read Triggered");
            var batchId = activityContext.GetInput<Guid>();

           string GetFetchQuery(int pageNumber, string pagingCookie, int pageCount)
            {
                return $@"<fetch count='{pageCount}' page='{pageNumber}' {(pageNumber > 1 ? $"paging-cookie=\"{pagingCookie}\"" : "")} latematerialize='true' no-lock='true'>
                           <entity name='ecr_notice'>
                            <attribute name='ecr_noticeid' />
                            <attribute name='ecr_enforcementcaseid' />
                            <attribute name='statuscode' />
                            <attribute name='ecr_noticetype' />
                            <attribute name='ecr_phonecallissueddate' />
                            <attribute name='ecr_issuedate' />
                            <attribute name='ecr_escalatetofpndate' />
                            <attribute name='ecr_deadline' />
                            <attribute name='ecr_epncreatedon' />
                            <link-entity name='ecr_enforcementcase' to='ecr_enforcementcaseid' from='ecr_enforcementcaseid' alias='ecase' link-type='inner'>
                              <attribute name='ecr_enforcementcaseid' />
                              <attribute name='statuscode' />
                              <attribute name='ecr_enforcementjourney' />
                              <attribute name='ecr_casetype' />
                                <filter>
                                    <condition attribute='statecode' operator='eq' value='0' />                             
                                 </filter>
                            </link-entity>
                            <link-entity name='account' to='ecr_organisationid' from='accountid' alias='org' link-type='inner'>
                              <attribute name='accountid' />
                                <filter>
                                    <condition attribute='statecode' operator='eq' value='0' />                             
                                 </filter>
                            </link-entity>
                            <filter>
                              <condition attribute='statecode' operator='eq' value='0' />
                              
                            </filter>
                          </entity>
                        </fetch>";
            }

            int totalEntityCount = 0;
            int totalEntityStoredCount = 0;
            MetricTimer timers = new MetricTimer(Constants.EnforcementScheduleTaskCategory, Constants.EnsureSchedules, ConfigurationManager.AppSettings["APPINSIGHTS_INSTRUMENTATIONKEY"], ConfigurationManager.AppSettings["EnableCustomMetricCRM"], ConfigurationManager.AppSettings["EnableCustomMetricTable"]);
                try
                { 
                        int pageNumber = 1;
                        string pagingCookie = null;
                        int pageCount = config.CRMReadPageSize > 1 ? config.CRMReadPageSize : 500;
             

                        while (true)
                        {
                            List<BatchRecord> batchRecords = new List<BatchRecord>();
                            int entityFilteredCount = 0;
                            timers.CRMReadStart();
                            var results = crmConnection.Service.RetrieveMultiple(new FetchExpression(GetFetchQuery(pageNumber, pagingCookie, pageCount)));
                            timers.CRMReadStop();
                            totalEntityCount += results.Entities.Count;

                            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedules - Read - Entity Count {results.Entities.Count}");

                            foreach (var entity in results.Entities)
                            {
                                try
                                {

                                    var notice = new Entity();

                                    notice.LogicalName = "ecr_notice";
                                    notice["ecr_noticeid"] = entity["ecr_noticeid"];
                                    notice["ecr_enforcementcaseid"] = entity.Contains("ecr_enforcementcaseid") ? ((Microsoft.Xrm.Sdk.EntityReference)entity["ecr_enforcementcaseid"]) : null;
                                     notice["statuscode"] = entity.Contains("statuscode") ? entity.GetAttributeValue<OptionSetValue>("statuscode") : null;
                                    notice["ecr_noticetype"] = entity.Contains("ecr_noticetype") ? entity.GetAttributeValue<OptionSetValue>("ecr_noticetype") : null;
                                    notice["ecr_phonecallissueddate"] = entity.Contains("ecr_phonecallissueddate") ? entity["ecr_phonecallissueddate"] : null;
                                    notice["ecr_issuedate"] = entity.Contains("ecr_issuedate") ? entity["ecr_issuedate"] : null;
                                    notice["ecr_escalatetofpndate"] = entity.Contains("ecr_escalatetofpndate") ? entity["ecr_escalatetofpndate"] : null;
                                    notice["ecr_deadline"] = (entity.Contains("ecr_deadline") ? entity["ecr_deadline"] : null);
                                    notice["ecr_epncreatedon"] = entity.Contains("ecr_epncreatedon") ? entity["ecr_epncreatedon"] : null;
                                        
                                    var enforcementCase = new Entity();

                                    enforcementCase.LogicalName = "ecr_enforcementcase"; 
                                    enforcementCase["ecr_enforcementcaseid"] = entity.Contains("ecase.ecr_enforcementcaseid") ? ((AliasedValue)entity["ecase.ecr_enforcementcaseid"]).Value : Guid.Empty; 
                                    enforcementCase["statuscode"] = entity.Contains("ecase.statuscode") ? (OptionSetValue)entity.GetAttributeValue<AliasedValue>("ecase.statuscode").Value : null;
                                    enforcementCase["ecr_enforcementjourney"] = entity.Contains("ecase.ecr_enforcementjourney") ? (OptionSetValue)entity.GetAttributeValue<AliasedValue>("ecase.ecr_enforcementjourney").Value : null;
                                    enforcementCase["ecr_casetype"] = entity.Contains("ecase.ecr_casetype") ? (OptionSetValue)entity.GetAttributeValue<AliasedValue>("ecase.ecr_casetype").Value : null;


                                    var account = new Entity();
                                    account.LogicalName = "account";
                                    account["accountid"] = entity.Contains("org.accountid") ? ((AliasedValue)entity["org.accountid"]).Value : null;

                                    //Casting it to Custom type to make it Serializable
                                    var ensureSchedulesEntity = new EnsureSchedulesEntities { Notice = notice, Account = account, EnforcementCase = enforcementCase };

                                    entityFilteredCount++;
                                    using (var ms = new MemoryStream())
                                    {
                                        lateBoundSerializer.WriteObject(ms, ensureSchedulesEntity);
                                        ms.Position = 0;

                                        var reader = new StreamReader(ms);
                                        var msg = reader.ReadToEnd();

                                        BatchRecord batchRecord = new BatchRecord(batchId, Constants.EnforcementScheduleTaskCategory, "EnsureSchedules", msg, null, "New", DateTime.Now, null, Guid.NewGuid().ToString(), account.Attributes["accountid"].ToString());
                                        batchRecords.Add(batchRecord);

                                        
                                    }
                                
                                    if (batchRecords.Count >= 50)
                                    {
                                        timers.TableWriteStart();
                                        await storageOperations.InsertBatch(config.BatchTableName, batchRecords);
                                        batchRecords.Clear();
                                        timers.TableWriteStop();
                                    }
                                }
                                catch (Exception ex)
                                {
                                    log.LogError(ex.ToString());
                                   
                                }
                            }

                            totalEntityStoredCount += entityFilteredCount;

                            if (batchRecords.Count > 0)
                            {
                                timers.TableWriteStart();
                                await storageOperations.InsertBatch(config.BatchTableName, batchRecords);
                                timers.TableWriteStop();
                            }

                            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedules - Read - Page {pageNumber} Complete - {entityFilteredCount}/{results.Entities.Count} passed checks and stored in blob");


                            if (!results.MoreRecords)
                                break;
                            pageNumber++;
                            pagingCookie = HttpUtility.HtmlEncode(results.PagingCookie);


                        }
                       

                        log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedules - Read Complete - Total Pages: {pageNumber} Total Entities Retrieved: {totalEntityCount} Total Entities Stored in Blob: {totalEntityStoredCount} ");
            }
            catch (Exception ex)
            {
                log.LogError(ex.ToString());
                throw ex;
            }

            timers.LogCRMRead(totalEntityCount);
            timers.LogTableWrite(totalEntityStoredCount);
            return totalEntityStoredCount;
           
        }
    }
}
