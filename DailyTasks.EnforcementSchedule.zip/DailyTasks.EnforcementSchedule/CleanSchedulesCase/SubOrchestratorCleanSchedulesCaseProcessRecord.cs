﻿using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace DailyTasks.EnforcementSchedule.CleanSchedulesCase
{
    public static class SubOrchestrator
    {
        [FunctionName("CleanSchedulesCase-SubOrchestrator-ProcessRecord")]
        public static async Task ProcessSubOrchestratorRecord(
            [OrchestrationTrigger] DurableOrchestrationContextBase context,
            ILogger log)
        {
            if (!context.IsReplaying) log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {Constants.CleanSchedulesCase} - SubOrchestrator - SubOrchestrator ProcessRecord Started");

            var record = context.GetInput<BatchRecord>();
            var dailyTaskName = Constants.EnsureSchedules;

            //Call Activities to Update CRM and Table Storage
            var enrichedBatchRecord = await context.CallActivityAsync<BatchRecord>("Activity-EnrichBatchRecord", (record, dailyTaskName));
            var updatedRecord = await context.CallActivityAsync<BatchRecord>("CleanSchedulesCase-Process-UpdateCrm", enrichedBatchRecord);
            await context.CallActivityAsync<BatchRecord>("Activity-UpdateTable", (updatedRecord, dailyTaskName));
        }
    }
}
