﻿using AzureFunctions.Autofac;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage;
using DailyTasks.Shared.Storage.Models;
using ECR.Core.CrmService;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Web;

namespace DailyTasks.EnforcementSchedule.CleanSchedulesCase
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityRead
    {
        private static DataContractSerializer lateBoundSerializer = new DataContractSerializer(typeof(CleanSchedulesEntities));

        [FunctionName("CleanSchedulesCase-Read")]
        public static async Task<int> CleanSchedulesCaseRead(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            ILogger log,
            [Inject] ICRMConnection crmConnection,
            [Inject] IStorageOperations storageOperations,
            [Inject] IConfig config)
        {
            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - CleanSchedulesCase - Activity - Read Triggered");
            var batchId = activityContext.GetInput<Guid>();

            //var entities = (from ecr_enforcementschedule in crmConnection.ServiceContext.CreateQuery("ecr_enforcementschedule")
            //                join ecr_enforcementcase in crmConnection.ServiceContext.CreateQuery("ecr_enforcementcase")
            //                on ((EntityReference)ecr_enforcementschedule["ecr_enforcementcaseid"]).Id equals (Guid)ecr_enforcementcase["ecr_enforcementcaseid"]
            //                where ((OptionSetValue)ecr_enforcementcase["statecode"]).Value == 1 // Closed
            //                where ((OptionSetValue)ecr_enforcementschedule["statecode"]).Value == 0 // Open
            //                select new
            //                {
            //                    EnforcementCase = new Entity()
            //                    {
            //                        LogicalName = ecr_enforcementcase.LogicalName,
            //                        Id = ecr_enforcementcase.Id,
            //                        Attributes = new AttributeCollection() {
            //                            {"ecr_enforcementcaseid", ecr_enforcementcase["ecr_enforcementcaseid"]},
            //                            {"statuscode", ecr_enforcementcase["statuscode"]}
            //                        }

            //                    },
            //                    EnforcementSchedule = new Entity()
            //                    {
            //                        LogicalName = ecr_enforcementschedule.LogicalName,
            //                        Id = ecr_enforcementschedule.Id,
            //                        Attributes = new AttributeCollection() {
            //                            {" ", ecr_enforcementschedule["ecr_enforcementscheduleid"]},
            //                            {"statuscode", ecr_enforcementschedule["statuscode"]}
            //                        }
            //                    }
            //                });

            string GetFetchQuery(int pageNumber, string pagingCookie, int count)
            {
                return $@"<fetch count='{count}' page='{pageNumber}' {(pageNumber > 1 ? $"paging-cookie=\"{pagingCookie}\"" : "")} latematerialize='true' no-lock='true'>
                            <entity name='ecr_enforcementschedule'>
                            <attribute name='ecr_enforcementscheduleid' />
                            <attribute name='statuscode' />
                            <link-entity name='ecr_enforcementcase' to='ecr_enforcementcaseid' from='ecr_enforcementcaseid' alias='ecase' link-type='inner'>
                              <attribute name='ecr_enforcementcaseid' />
                              <attribute name='statuscode' />
                                    <filter>
                                            <condition attribute='statecode' operator='eq' value='1' />                              
                                   </filter>
                            </link-entity>
                            <filter>
                              <condition attribute='statecode' operator='eq' value='0' />
                            </filter>
                          </entity>
                        </fetch>";
            }

            int totalEntityCount = 0;
            int totalEntityStoredCount = 0;
            MetricTimer timers = new MetricTimer(Constants.EnforcementScheduleTaskCategory, Constants.CleanSchedulesCase, ConfigurationManager.AppSettings["APPINSIGHTS_INSTRUMENTATIONKEY"], ConfigurationManager.AppSettings["EnableCustomMetricCRM"], ConfigurationManager.AppSettings["EnableCustomMetricTable"]);
            try
            {
                int pageNumber = 1;
                string pagingCookie = null;

                while (true)
                {
                    List<BatchRecord> batchRecords = new List<BatchRecord>();
                    int entityFilteredCount = 0;
                    timers.CRMReadStart();
                    var results = crmConnection.Service.RetrieveMultiple(new FetchExpression(GetFetchQuery(pageNumber, pagingCookie, config.CRMReadPageSize)));
                    timers.CRMReadStop();
                    totalEntityCount += results.Entities.Count;

                    log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - CleanSchedulesCase - Read - Page {pageNumber} Processing {results.Entities.Count} records");
                    foreach (var entity in results.Entities)
                    {
                        try
                        {
                            var EnforcementCase = new Entity()
                            {
                                LogicalName = "ecr_enforcementcase",
                                Id = entity.Contains("ecase.ecr_enforcementcaseid") ? Guid.Parse(entity.GetAttributeValue<AliasedValue>("ecase.ecr_enforcementcaseid").Value.ToString()) : Guid.Empty,
                                Attributes = new AttributeCollection() {
                                { "ecr_enforcementcaseid", entity.Contains("ecase.ecr_enforcementcaseid") ? Guid.Parse(entity.GetAttributeValue<AliasedValue>("ecase.ecr_enforcementcaseid").Value.ToString()) : Guid.Empty },
                                { "statuscode", entity.Contains("ecase.statuscode") ? (OptionSetValue)entity.GetAttributeValue<AliasedValue>("ecase.statuscode").Value : null },
                            }
                            };

                            var EnforcementSchedule = new Entity()
                            {
                                LogicalName = "ecr_enforcementschedule",
                                Id = entity.Contains("ecr_enforcementscheduleid") ? Guid.Parse(entity.GetAttributeValue<object>("ecr_enforcementscheduleid").ToString())  : Guid.Empty,
                                Attributes = new AttributeCollection() {
                                { "ecr_enforcementscheduleid", entity.Contains("ecr_enforcementscheduleid") ? Guid.Parse(entity.GetAttributeValue<object>("ecr_enforcementscheduleid").ToString()) : Guid.Empty },
                                { "statuscode", entity.Contains("statuscode") ? entity.GetAttributeValue<OptionSetValue>("statuscode") : null },
                            }
                            };

                            var cleanSchedulesEntities = new CleanSchedulesEntities { EnforcementCase = EnforcementCase, EnforcementSchedule = EnforcementSchedule };

                            using (var ms = new MemoryStream())
                            using (var reader = new StreamReader(ms))
                            {
                                lateBoundSerializer.WriteObject(ms, cleanSchedulesEntities);
                                ms.Position = 0;
                                var msg = reader.ReadToEnd();

                                BatchRecord batchRecord = new BatchRecord(batchId, Constants.EnforcementScheduleTaskCategory, "CleanSchedulesCase", msg, null, "New", DateTime.Now, null, Guid.NewGuid().ToString(), EnforcementCase.Attributes["ecr_enforcementcaseid"].ToString());
                                batchRecords.Add(batchRecord);
                                entityFilteredCount++;
                            }

                            if (batchRecords.Count >= 50)
                            {
                                timers.TableWriteStart();
                                await storageOperations.InsertBatch(config.BatchTableName, batchRecords);
                                batchRecords.Clear();
                                timers.TableWriteStop();
                            }
                        }
                        catch (Exception ex)
                        {
                            log.LogError(ex.ToString());
                        }
                    }
                    totalEntityStoredCount += entityFilteredCount;

                    if (batchRecords.Count > 0)
                    {
                        timers.TableWriteStart();
                        await storageOperations.InsertBatch(config.BatchTableName, batchRecords);
                        timers.TableWriteStop();
                    }
                    log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - CleanSchedulesCase - Read - Page {pageNumber} Complete - {entityFilteredCount}/{results.Entities.Count} passed checks and stored in blob");

                    if (!results.MoreRecords)
                        break;
                    pageNumber++;
                    pagingCookie = HttpUtility.HtmlEncode(results.PagingCookie);
                }

                log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - CleanSchedulesCase - Read Complete - Total Pages: {pageNumber} Total Entities Retrieved: {totalEntityCount} Total Entities Stored in Blob: {totalEntityStoredCount} ");
            }
            catch (Exception ex)
            {
                log.LogError(ex.ToString());
                throw ex;
            }

            timers.LogCRMRead(totalEntityCount);
            timers.LogTableWrite(totalEntityStoredCount);

            return totalEntityStoredCount;
        }
    }
}
