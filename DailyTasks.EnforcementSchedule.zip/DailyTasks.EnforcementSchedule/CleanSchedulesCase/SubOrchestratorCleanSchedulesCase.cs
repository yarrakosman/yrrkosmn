﻿using System;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Configuration;
using MoreLinq;

namespace DailyTasks.EnforcementSchedule.CleanSchedulesCase
{
    public static class SubOrchestratorCleanSchedulesCase
    {
        [FunctionName("CleanSchedulesCase-SubOrchestrator")]
        public static async Task CleanSchedulesCaseSubOrchestratorEnsureSchedules(
            [OrchestrationTrigger] DurableOrchestrationContextBase context,
            ILogger log)
        {
            var dailyTaskName = Constants.CleanSchedulesCase;

            if (!context.IsReplaying) log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {dailyTaskName} - SubOrchestrator Started");
            DateTime startTime = context.CurrentUtcDateTime;

            //Get Batch Id for this Batch
            var batchId = await context.CallActivityAsync<Guid>("Activity-GetBatchId", null);

            try
            {
                //Log Start in Table Storage
                await context.CallActivityAsync<string>("Activity-InsertStatus", (batchId, dailyTaskName, Constants.TaskStatusStarted, string.Empty));

                //Call Activities to Read CRM, Read Batch from Table Storage and Update CRM and Table Storage
                var recordCount = await context.CallActivityAsync<int>($"{dailyTaskName}-Read", batchId);

                //Only proceed if batch has more than 0 records
                if (recordCount > 0)
                {
                    DateTime startReadTime = context.CurrentUtcDateTime;
                    var batch = await context.CallActivityAsync<List<BatchRecord>>("Activity-GetBatch", (batchId, dailyTaskName));
                    if (!context.IsReplaying)
                    {
                        MetricTimer timers = new MetricTimer(Constants.EnforcementScheduleTaskCategory, Constants.CleanSchedulesCase, ConfigurationManager.AppSettings["APPINSIGHTS_INSTRUMENTATIONKEY"], ConfigurationManager.AppSettings["EnableCustomMetricCRM"], ConfigurationManager.AppSettings["EnableCustomMetricTable"]);
                        timers.LogTableRead(batch.Count, startReadTime, context.CurrentUtcDateTime);
                    }
                  
                    DateTime startWriteTime = context.CurrentUtcDateTime;

                    int batchCount = 100;
                    if (!int.TryParse(ConfigurationManager.AppSettings["CRMBatchUpdateConfig"], out batchCount))
                    {
                        batchCount = 100;
                    }
                    foreach (var records in batch.Batch(batchCount))
                    {
                        var tasks = new List<Task>();
                        foreach (var record in records)
                        {
                            tasks.Add(context.CallSubOrchestratorAsync(
                            $"{dailyTaskName}-SubOrchestrator-ProcessRecord",
                            record));
                        }
                        await Task.WhenAll(tasks);
                    }

                    if (!context.IsReplaying)
                    {
                        MetricTimer timers = new MetricTimer(Constants.EnforcementScheduleTaskCategory, Constants.CleanSchedulesCase, ConfigurationManager.AppSettings["APPINSIGHTS_INSTRUMENTATIONKEY"], ConfigurationManager.AppSettings["EnableCustomMetricCRM"], ConfigurationManager.AppSettings["EnableCustomMetricTable"]);
                        timers.LogCRMWrite(batch.Count, startWriteTime, context.CurrentUtcDateTime);
                    }
                }

                //Log End in Table Storage
                await context.CallActivityAsync<string>("Activity-InsertStatus", (batchId, dailyTaskName, Constants.TaskStatusEnded, string.Empty));
                if (!context.IsReplaying)
                {
                    MetricTimer timers = new MetricTimer(Constants.EnforcementScheduleTaskCategory, Constants.CleanSchedulesCase, ConfigurationManager.AppSettings["APPINSIGHTS_INSTRUMENTATIONKEY"], ConfigurationManager.AppSettings["EnableCustomMetricOrchestrator"]);
                    timers.LogSubOrchestrationRun(startTime, context.CurrentUtcDateTime);
                }
            }
            catch (Exception ex)
            {
                log.LogError($"{Constants.EnforcementScheduleTaskCategory} - {dailyTaskName} - Exception - {ex.Message} - Stack Trace - {ex.StackTrace}");
                await context.CallActivityAsync<string>("Activity-InsertStatus", (batchId, dailyTaskName, Constants.TaskFailedStatus, ex.Message));
            }
        }
    }
}
