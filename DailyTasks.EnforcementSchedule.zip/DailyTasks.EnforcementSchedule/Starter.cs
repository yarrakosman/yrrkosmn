using DailyTasks.Shared.Dtos;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.ServiceBus.Messaging;
using System.Threading.Tasks;

namespace DailyTasks.EnforcementSchedule
{
    public static class Starter
    {
        [FunctionName("Starter")]
        public static async Task RunOrchestrator(
            [ServiceBusTrigger("%QueueName%", AccessRights.Manage, Connection = "ServiceBusConnectionString")] string queueMessage,
            [OrchestrationClient] DurableOrchestrationClientBase client,
            ILogger log
            )
        {
            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - Orchestration Client ServiceBus queue trigger function processed message: {queueMessage}");
            await client.StartNewAsync("Orchestrator", queueMessage);
        }
    }
}
