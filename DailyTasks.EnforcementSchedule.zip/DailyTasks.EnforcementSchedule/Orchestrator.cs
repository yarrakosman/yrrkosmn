﻿using DailyTasks.Shared.Dtos;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace DailyTasks.EnforcementSchedule
{
    public class Orchestrator
    {
        [FunctionName("Orchestrator")]
        public static async Task EnforcementScheduleOrchestrator(
            [OrchestrationTrigger] DurableOrchestrationContextBase context,
            ILogger log)
        {
            if (!context.IsReplaying) log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - Orchestrator Started");

            var triggerNotificationJson = context.GetInput<string>();
            var triggerNotification = JsonConvert.DeserializeObject<TaskTrigger>(triggerNotificationJson);

            //Invoke all Daily Tasks one by one
            await context.CallSubOrchestratorAsync("CleanSchedulesCase-SubOrchestrator", null);
            await context.CallSubOrchestratorAsync("CleanSchedulesNotice-SubOrchestrator", null);
            await context.CallSubOrchestratorAsync("CleanSchedulesPenalty-SubOrchestrator", null);

            await context.CallSubOrchestratorAsync("EnsureSchedulesCase-SubOrchestrator", null);
            await context.CallSubOrchestratorAsync("EnsureSchedules-SubOrchestrator", null);
            await context.CallSubOrchestratorAsync("EnsureSchedulesPenalty-SubOrchestrator", null);

            // Write complete message to message bus for scheduler. 
            await context.CallActivityAsync("EnforcementSchedule-DTComplete", null);
        }
    }
}
