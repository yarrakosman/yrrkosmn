﻿using AzureFunctions.Autofac;
using DailyTasks.Shared.Crm;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Pluggable;
using DailyTasks.Shared.Storage;
using DailyTasks.Shared.Storage.Models;
using ECR.Core.CrmService;
using ECR.Enforcement;
using ECR.Enforcement.Interfaces;
using ECR.Enforcement.States.EnforcementSchedule;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Text;

namespace DailyTasks.EnforcementSchedule.CleanSchedulesNotice
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityUpdateCrm
    {
        private readonly static DataContractSerializer lateBoundSerializer = new DataContractSerializer(typeof(CleanSchedulesEntities));

        [FunctionName("CleanSchedulesNotice-Process-UpdateCrm")]
        public static BatchRecord CleanSchedulesNoticeProcessUpdateCrm(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            [Inject] IEnforcementValuesProvider enforcementValuesProvider,
            [Inject] ICRMConnection crmConnection,
            ILogger log,
            [Inject] IBatchUpdateProvider batchUpdateProvider)
        {
            var dailyTaskName = Constants.CleanSchedulesNotice;

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {dailyTaskName} - Activity - UpdateCrm Triggered");
            var record = activityContext.GetInput<BatchRecord>();

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {dailyTaskName} - Activity - UpdateCrm - Executing for Organization Id {record.EntityId}");

            var enforcementValues = enforcementValuesProvider.Values;

            try
            {
                CleanSchedulesEntities cleanSchedulesEntities = null;

                using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(record.RequestMessage)))
                {
                    cleanSchedulesEntities = (CleanSchedulesEntities)lateBoundSerializer.ReadObject(ms);

                    NewEnforcementContext enforcementContext = new NewEnforcementContext(
                        crmConnection.Service,
                        crmConnection.ServiceContext,
                        new ClosedNoticeOpenSchedule(),
                        enforcementValues,
                        new List<Entity>() { cleanSchedulesEntities.EnforcementCase, cleanSchedulesEntities.EnforcementSchedule },
                        null)
                    {
                        CRMBatchEnabled = true
                    };

                    ProcessRecord(enforcementContext);
                    var isProcessed = RunStates.ExecuteStateModel(enforcementContext);

                    if (isProcessed)
                    {
                        //Only do the Batch Update if transactions are added to the context
                        if (enforcementContext.CRMRequests.Count > 0)
                        {
                            //Now do the commits to CRM by executing the Batch
                            record.ErrorDescription = batchUpdateProvider.BatchUpdateCrm(enforcementContext, crmConnection, true);

                            if (!string.IsNullOrEmpty(record.ErrorDescription))
                            {
                                record.Status = "ProcessFailed";
                            }
                            else
                            {
                                record.Status = "Processed";
                            }
                        }
                        else
                        {
                            record.Status = "Ignored";
                        }
                    }
                    else
                    {
                        record.Status = "ProcessFailed";
                    }
                }

            }
            catch (Exception ex)
            {
                log.LogError(ex.ToString());
                record.Status = "ProcessFailed";
                record.ErrorDescription = ex.ToString();
            }

            return record;
        }

        private static bool ProcessRecord(IEnforcementContext context)
        {
            ((NewEnforcementContext)context).Populate();
            return (true);
        }
    }
}
