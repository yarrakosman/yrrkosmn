﻿using AzureFunctions.Autofac;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage;
using DailyTasks.Shared.Storage.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;

namespace DailyTasks.EnforcementSchedule.CommonActivities
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityUpdateTable
    {
        [FunctionName("Activity-UpdateTable")]
        public static void ProcessUpdateTable(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            [Inject] IConfig config,
            [Inject] IStorageOperations storageOperations,
            ILogger log)
        {
            var (record, dailyTaskName) = activityContext.GetInput<(BatchRecord, string)>();

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {dailyTaskName} - Activity - UpdateTable Triggered");

            storageOperations.UpdateRecord(config.BatchTableName, record);

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {dailyTaskName} - Activity - UpdateTableRecord Complete");
        }
    }

}
