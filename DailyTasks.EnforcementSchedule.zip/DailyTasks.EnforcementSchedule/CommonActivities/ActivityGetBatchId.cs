﻿using System;
using AzureFunctions.Autofac;
using Microsoft.Azure.WebJobs;

namespace DailyTasks.EnforcementSchedule.CommonActivities
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityGetBatchId
    {
        [FunctionName("Activity-GetBatchId")]
        public static Guid ProcessGetBatchId(
            [ActivityTrigger] DurableActivityContextBase activityContext)
        {
            return Guid.NewGuid();
        }
    }
}
