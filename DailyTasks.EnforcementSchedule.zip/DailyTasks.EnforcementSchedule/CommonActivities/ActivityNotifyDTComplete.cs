﻿using AzureFunctions.Autofac;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace DailyTasks.EnforcementSchedule.CommonActivities
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityNotifyDTComplete
    {
        [FunctionName("EnforcementSchedule-DTComplete")]
        public static async Task StartEnforcementScheduleDTComplete(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            [Inject] IConfig config,
            [Inject] IServiceBusOperations serviceBusOperations,
            ILogger log)
        {
            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - Activity - DTComplete Triggered");

            string message = JsonConvert.SerializeObject(new
            {
                TaskCategory = Constants.EnforcementScheduleTaskCategory
            });

            await serviceBusOperations.SendMessageToDTCompleteQueue(message);

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - Activity - DTComplete Complete");
        }
    }
}
