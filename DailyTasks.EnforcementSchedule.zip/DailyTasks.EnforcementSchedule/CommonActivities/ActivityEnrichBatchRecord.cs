﻿using AzureFunctions.Autofac;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage;
using DailyTasks.Shared.Storage.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;

namespace DailyTasks.EnforcementSchedule.CommonActivities
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityEnrichBatchRecord
    {
        [FunctionName("Activity-EnrichBatchRecord")]
        public static BatchRecord ProcessEnrichBatchRecord(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            [Inject] IStorageOperations storageOperations,
            ILogger log)
        {
            var (record, dailyTaskName) = activityContext.GetInput<(BatchRecord, string)>();

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {dailyTaskName} - Activity - EnrichBatchRecord Triggered for Batch Record {record.RowKey}");

            var requestMessage = storageOperations.GetBlobText(record.RequestBlobLink);
            record.RequestMessage = requestMessage;

            return record;
        }
    }
}
