﻿using System.Collections.Generic;
using AzureFunctions.Autofac;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage;
using DailyTasks.Shared.Storage.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;

namespace DailyTasks.EnforcementSchedule.CommonActivities
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityGetBatch
    {
        [FunctionName("Activity-GetBatch")]
        public static List<BatchRecord> ProcessGetBatch(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            [Inject] IStorageOperations storageOperations,
            [Inject] IConfig config,
            ILogger log)
        {
            var (batchId, dailyTaskName) = activityContext.GetInput<(string, string)>();

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {dailyTaskName} - Activity - GetBatch Triggered for BatchId: {batchId}");

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {dailyTaskName} - Activity - GetBatch - BatchId Received: {batchId}");

            if (!string.IsNullOrWhiteSpace(batchId))
            {
                var batch = storageOperations.RetrieveAllTableRecords(config.BatchTableName, batchId);
                log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {dailyTaskName} - Activity - GetBatch - Batch Count: {batch.Count}");
                return batch;
            }

            return null;
        }
    }
}
