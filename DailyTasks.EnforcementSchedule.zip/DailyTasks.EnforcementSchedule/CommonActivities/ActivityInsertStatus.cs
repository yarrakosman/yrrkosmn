﻿using System;
using System.Threading.Tasks;
using AzureFunctions.Autofac;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage;
using DailyTasks.Shared.Storage.Models;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;

namespace DailyTasks.EnforcementSchedule.CommonActivities
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityInsertStatus
    {
        [FunctionName("Activity-InsertStatus")]
        public static async Task ProcessInsertStatus(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            [Inject] IConfig config,
            [Inject] IStorageOperations storageOperations,
            ILogger log)
        {
            var (batchId, taskName, taskStatus, errorMessage) = activityContext.GetInput<(Guid, string, string, string)>();

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {taskName}  - Activity - InsertStatus Triggered");

            var batchRecord = new BatchRecord
            {
                BatchId = batchId,
                PartitionKey = batchId.ToString(),
                RowKey = Guid.NewGuid().ToString(),
                TaskCategory = Constants.EnforcementScheduleTaskCategory,
                Task = taskName,
                DateCreated = DateTime.Now,
                Status = taskStatus,
                ErrorDescription = errorMessage
            };

            await storageOperations.InsertRecord(config.BatchTableName, batchRecord, null);

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - {taskName}  - Activity - InsertStatus Record Complete");
        }
    }
}
