﻿using Autofac;
using AzureFunctions.Autofac.Configuration;
using DailyTasks.Shared.Crm;
using DailyTasks.Shared.Storage;
using ECR.Core.CrmService;
using ECR.CrmService;

namespace DailyTasks.EnforcementSchedule
{
    public class DIConfig
    {
        public DIConfig(string functionName)
        {
            DependencyInjection.Initialize(builder =>
            {
                // Singletons
                builder.RegisterType<StorageOperations>().As<IStorageOperations>().SingleInstance();
                builder.RegisterType<Config>().As<IConfig>().SingleInstance();
                builder.RegisterType<CRMConnection>().As<ICRMConnection>().WithParameter("isConnectionPool", true);
                builder.RegisterType<EnforcementValuesProvider>().As<IEnforcementValuesProvider>().SingleInstance();
                builder.RegisterType<BatchUpdateProvider>().As<IBatchUpdateProvider>();
                builder.RegisterType<ServiceBusOperations>().As<IServiceBusOperations>().SingleInstance();

            }, functionName);
        }
    }
}
