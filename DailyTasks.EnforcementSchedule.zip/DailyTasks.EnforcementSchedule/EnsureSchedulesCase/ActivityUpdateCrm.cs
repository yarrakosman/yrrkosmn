﻿using System;
using DailyTasks.Shared.Storage.Models;
using DailyTasks.Shared.Storage;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using AzureFunctions.Autofac;
using ECR.Core.CrmService;
using DailyTasks.Shared.Dtos;
using ECR.Enforcement.Interfaces;
using ECR.Enforcement;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk;
using ECR.Enforcement.States.EnforcementSchedule;
using System.Runtime.Serialization;
using System.Text;
using DailyTasks.Shared.Pluggable;
using DailyTasks.Shared.Crm;

namespace DailyTasks.EnforcementSchedule.EnsureSchedulesCase
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityUpdateCrm
    {
        private readonly static DataContractSerializer lateBoundSerializer = new DataContractSerializer(typeof(EnsureSchedulesCaseEntities));

        [FunctionName("EnsureSchedulesCase-Process-UpdateCrm")]
        public static BatchRecord EnsureSchedulesCaseProcessUpdateCrm(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            [Inject] IEnforcementValuesProvider enforcementValuesProvider,
            [Inject] ICRMConnection crmConnection,
            ILogger log,
            [Inject] IBatchUpdateProvider batchUpdateProvider)
        {
            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedulesCase - Activity - UpdateCrm Triggered");
            var record = activityContext.GetInput<BatchRecord>();

            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedulesCase - Activity - UpdateCrm - Executing for Organization Id {record.EntityId}");

            var enforcementValues = enforcementValuesProvider.Values;

            try
            {
                EnsureSchedulesCaseEntities ensureSchedulesCaseEntities = null;

                using (var ms = new MemoryStream(Encoding.UTF8.GetBytes(record.RequestMessage)))
                {
                    ensureSchedulesCaseEntities = (EnsureSchedulesCaseEntities)lateBoundSerializer.ReadObject(ms);

                    NewEnforcementContext enforcementContext = new NewEnforcementContext(
                        crmConnection.Service,
                        crmConnection.ServiceContext,
                        new StartScheduleUpdateForCase(),
                        enforcementValues,
                        new List<Entity>() { ensureSchedulesCaseEntities.EnforcementCase, ensureSchedulesCaseEntities.Account },
                        null)
                    {
                        CRMBatchEnabled = true
                    };

                    ProcessRecord(enforcementContext);
                    var isProcessed = RunStates.ExecuteStateModel(enforcementContext);

                    if (isProcessed)
                    {
                        //Only do the Batch Update if transactions are added to the context
                        if (enforcementContext.CRMRequests.Count > 0)
                        {
                            //Now do the commits to CRM by executing the Batch
                            record.ErrorDescription = batchUpdateProvider.BatchUpdateCrm(enforcementContext, crmConnection, true);

                            if (!string.IsNullOrEmpty(record.ErrorDescription))
                            {
                                record.Status = "ProcessFailed";
                            }
                            else
                            {
                                record.Status = "Processed";
                            }
                        }
                        else
                        {
                            record.Status = "Ignored";
                        }
                    }
                    else
                    {
                        record.Status = "ProcessFailed";
                    }
                }

            }
            catch (Exception ex)
            {
                log.LogError(ex.ToString());
                record.Status = "ProcessFailed";
                record.ErrorDescription = ex.ToString();
            }

            return record;
        }

        private static bool ProcessRecord(IEnforcementContext context)
        {
            ((NewEnforcementContext)context).Populate();
            ((NewEnforcementContext)context).SetSchedulesForCase();
            return (true);
        }
    }
}
