﻿using AzureFunctions.Autofac;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage;
using DailyTasks.Shared.Storage.Models;
using ECR.Core.CrmService;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Web;

namespace DailyTasks.EnforcementSchedule.EnsureSchedulesCase
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityRead
    {
        private static DataContractSerializer lateBoundSerializer = new DataContractSerializer(typeof(EnsureSchedulesCaseEntities));


        [FunctionName("EnsureSchedulesCase-Read")]
        public static async Task<int> EnsureSchedulesCaseRead(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            ILogger log,
            [Inject] ICRMConnection crmConnection,
            [Inject] IStorageOperations storageOperations,
            [Inject] IEnforcementValuesProvider enforcementValuesProvider,
            [Inject] IConfig config)
        {
            string logPrefix = $"{Constants.EnforcementScheduleTaskCategory} - {Constants.EnsureSchedulesCase}";
            log.LogInformation($"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedulesCase - Activity - Read Triggered");
            var batchId = activityContext.GetInput<Guid>();

            //var entities = (from ecr_enforcementcase in crmConnection.ServiceContext.CreateQuery("ecr_enforcementcase")

            //                join org in crmConnection.ServiceContext.CreateQuery("account")
            //                on ((EntityReference)ecr_enforcementcase["ecr_organisationid"]).Id equals (Guid)org["accountid"]

            //                where ((OptionSetValue)ecr_enforcementcase["statecode"]).Value == 0 // Open
            //                where ((OptionSetValue)org["statecode"]).Value == 0 // Open

            //                select new
            //                {
            //                    EnforcementCase = new Entity()
            //                    {
            //                        LogicalName = ecr_enforcementcase.LogicalName,
            //                        Id = ecr_enforcementcase.Id,
            //                        Attributes = new AttributeCollection() {
            //                        {"ecr_enforcementcaseid", ecr_enforcementcase["ecr_enforcementcaseid"]},
            //                        {"statuscode", ecr_enforcementcase["statuscode"]},
            //                        {"ecr_enforcementjourney", (ecr_enforcementcase.Contains("ecr_enforcementjourney") ? ecr_enforcementcase["ecr_enforcementjourney"] : null)},
            //                        {"ecr_warninglettercreatedate", (ecr_enforcementcase.Contains("ecr_warninglettercreatedate") ? ecr_enforcementcase["ecr_warninglettercreatedate"] : null)},
            //                        {"ecr_noticecreatedate", (ecr_enforcementcase.Contains("ecr_noticecreatedate") ? ecr_enforcementcase["ecr_noticecreatedate"] : null)},
            //                        {"ecr_casetype", (ecr_enforcementcase.Contains("ecr_casetype") ? ecr_enforcementcase["ecr_casetype"] : null)},
            //                        {"ecr_organisationid", (ecr_enforcementcase.Contains("ecr_organisationid") ? ecr_enforcementcase["ecr_organisationid"] : null)},
            //                      }
            //                    },
            //                    Account = new Entity()
            //                    {
            //                        LogicalName = org.LogicalName,
            //                        Id = org.Id,
            //                        Attributes = new AttributeCollection() {
            //                        {"accountid", org["accountid"]},
            //                        {"statuscode", (org.Contains("statuscode") ? org["statuscode"] : null)},
            //                        {"ecr_registrationstatus", (org.Contains("ecr_registrationstatus") ? org["ecr_registrationstatus"] : null)},
            //                        {"ecr_organisationtype", (org.Contains("ecr_organisationtype") ? org["ecr_organisationtype"] : null)}
            //                      }
            //                    }
            //                });

            string GetFetchQuery(int pageNumber, string pagingCookie, int pageCount)
            {
                return $@"<fetch count='{pageCount}' page='{pageNumber}' {(pageNumber > 1 ? $"paging-cookie=\"{pagingCookie}\"" : "")} latematerialize='true' no-lock='true'>
                             <entity name='ecr_enforcementcase'>
                                  <attribute name='ecr_enforcementcaseid' />
                                  <attribute name='statuscode' />
                                  <attribute name='ecr_enforcementjourney' />
                                  <attribute name='ecr_warninglettercreatedate' />
                                  <attribute name='ecr_noticecreatedate' />
                                  <attribute name='ecr_casetype' />
                                  <attribute name='ecr_organisationid' />

                                  <link-entity name='account' to='ecr_organisationid' from='accountid' alias='org' link-type='inner'>
                                       <attribute name='accountid' />
                                       <attribute name='statuscode' />
                                       <attribute name='ecr_registrationstatus' />
                                       <attribute name='ecr_organisationtype' />
                                        <filter>
                                            <condition attribute='statecode' operator='eq' value='0' />                             
                                        </filter>
                                  </link-entity>
                                  <filter>
                                        <condition attribute='statecode' operator='eq' value='0' />
                                  </filter>
                            </entity>
                            </fetch>";
            }


            int totalEntityCount = 0;
            int totalEntityStoredCount = 0;
            MetricTimer timers = new MetricTimer(Constants.EnforcementScheduleTaskCategory, Constants.EnsureSchedulesCase, ConfigurationManager.AppSettings["APPINSIGHTS_INSTRUMENTATIONKEY"], ConfigurationManager.AppSettings["EnableCustomMetricCRM"], ConfigurationManager.AppSettings["EnableCustomMetricTable"]);
            try
            {
                int pageNumber = 1;
                string pagingCookie = null;

                while (true)
                {
                    List<BatchRecord> batchRecords = new List<BatchRecord>();
                    int entityFilteredCount = 0;
                    timers.CRMReadStart();
                    var results = crmConnection.Service.RetrieveMultiple(new FetchExpression(GetFetchQuery(pageNumber, pagingCookie, config.CRMReadPageSize)));
                    timers.CRMReadStop();
                    totalEntityCount += results.Entities.Count;

                    log.LogInformation($"{logPrefix} - Read - Page {pageNumber} Processing {results.Entities.Count} records");

                    foreach (var entity in results.Entities)
                    {
                        try
                        {

                            var enforcementCase = new Entity
                            {
                                LogicalName = "ecr_enforcementcase",
                                Id = entity.Contains("ecr_enforcementcaseid") ? Guid.Parse(entity.GetAttributeValue<object>("ecr_enforcementcaseid").ToString()) : Guid.Empty,
                                ["ecr_enforcementcaseid"] = entity["ecr_enforcementcaseid"],
                                ["statuscode"] = entity.Contains("statuscode") ? (OptionSetValue)entity["statuscode"] : null,
                                ["ecr_enforcementjourney"] = entity.Contains("ecr_enforcementjourney") ? (OptionSetValue)entity["ecr_enforcementjourney"] : null,
                                ["ecr_casetype"] = entity.Contains("ecr_casetype") ? (OptionSetValue)entity["ecr_casetype"] : null,
                                ["ecr_organisationid"] = entity.Contains("ecr_organisationid") ? (EntityReference)entity["ecr_organisationid"] : null,

                            };

                            if (entity.Contains("ecr_warninglettercreatedate")) enforcementCase.Attributes.Add("ecr_warninglettercreatedate", (DateTime)entity["ecr_warninglettercreatedate"]);
                            else enforcementCase.Attributes.Add("ecr_warninglettercreatedate", null);

                            if (entity.Contains("ecr_noticecreatedate")) enforcementCase.Attributes.Add("ecr_noticecreatedate", (DateTime)entity["ecr_noticecreatedate"]);
                            else enforcementCase.Attributes.Add("ecr_noticecreatedate", null);

                            var account = new Entity();
                            account.LogicalName = "account";
                            account.Id = entity.Contains("org.accountid") ? Guid.Parse(entity.GetAttributeValue<AliasedValue>("org.accountid").Value.ToString()) : Guid.Empty;
                            account["accountid"] = entity.Contains("org.accountid") ? Guid.Parse(entity.GetAttributeValue<AliasedValue>("org.accountid").Value.ToString()) : Guid.Empty;
                            account["ecr_organisationtype"] = entity.Contains("org.ecr_organisationtype") ? (OptionSetValue)entity.GetAttributeValue<AliasedValue>("org.ecr_organisationtype").Value : null;
                            account["ecr_registrationstatus"] = entity.Contains("org.ecr_registrationstatus") ? (OptionSetValue)entity.GetAttributeValue<AliasedValue>("org.ecr_registrationstatus").Value : null;
                            account["statuscode"] = entity.Contains("org.statuscode") ? (OptionSetValue)entity.GetAttributeValue<AliasedValue>("org.statuscode").Value : null;


                            var ensureSchedulesCaseEntity = new EnsureSchedulesCaseEntities { Account = account, EnforcementCase = enforcementCase };


                            using (var ms = new MemoryStream())
                            using (var reader = new StreamReader(ms))
                            {
                                lateBoundSerializer.WriteObject(ms, ensureSchedulesCaseEntity);
                                ms.Position = 0;
                                var msg = reader.ReadToEnd();

                                BatchRecord batchRecord = new BatchRecord(batchId, Constants.EnforcementScheduleTaskCategory, Constants.EnsureSchedulesCase, msg, null, "New", DateTime.UtcNow, null, Guid.NewGuid().ToString(), ensureSchedulesCaseEntity.Account.Attributes["accountid"].ToString());
                                batchRecords.Add(batchRecord);
                                entityFilteredCount++;
                            }

                            if (batchRecords.Count >= 50)
                            {
                                timers.TableWriteStart();
                                await storageOperations.InsertBatch(config.BatchTableName, batchRecords);
                                batchRecords.Clear();
                                timers.TableWriteStop();
                            }
                        }
                                            
                        catch (Exception ex)
                        {
                            log.LogError(ex.ToString());
                            continue;
                        }
                    }
                    totalEntityStoredCount += entityFilteredCount;

                    if (batchRecords.Count > 0)
                    {
                        timers.TableWriteStart();
                        await storageOperations.InsertBatch(config.BatchTableName, batchRecords);
                        timers.TableWriteStop();
                    }
                    log.LogInformation($"{logPrefix} - Read - Page {pageNumber} Complete - {entityFilteredCount}/{results.Entities.Count} passed checks and stored in blob");

                    if (!results.MoreRecords)
                        break;
                    pageNumber++;
                    pagingCookie = HttpUtility.HtmlEncode(results.PagingCookie);
                }
                log.LogInformation($"{logPrefix} - Read Complete - Total Pages: {pageNumber} Total Entities Retrieved: {totalEntityCount} Total Entities Stored in Blob: {totalEntityStoredCount} ");
            }
            catch (Exception ex)
            {
                log.LogError(ex.ToString());
                throw ex;
            }

            timers.LogCRMRead(totalEntityCount);
            timers.LogTableWrite(totalEntityStoredCount);

            return totalEntityStoredCount;
        }
    }
}
