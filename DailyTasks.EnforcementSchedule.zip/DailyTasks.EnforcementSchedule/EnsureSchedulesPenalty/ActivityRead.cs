﻿using AzureFunctions.Autofac;
using DailyTasks.Shared.Dtos;
using DailyTasks.Shared.Storage;
using DailyTasks.Shared.Storage.Models;
using ECR.Core.CrmService;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using System.Web;

namespace DailyTasks.EnforcementSchedule.EnsureSchedulesPenalty
{
    [DependencyInjectionConfig(typeof(DIConfig))]
    public static class ActivityRead
    {
        private static DataContractSerializer lateBoundSerializer =
            new DataContractSerializer(typeof(EnsureSchedulesPenaltyEntities));


        [FunctionName("EnsureSchedulesPenalty-Read")]
        public static async Task<int> EnsureSchedulesPenaltyRead(
            [ActivityTrigger] DurableActivityContextBase activityContext,
            ILogger log,
            [Inject] ICRMConnection crmConnection,
            [Inject] IStorageOperations storageOperations,
            [Inject] IEnforcementValuesProvider enforcementValuesProvider,
            [Inject] IConfig config)
        {
            log.LogInformation(
                $"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedulesPenalty - Activity - Read Triggered");
            var batchId = activityContext.GetInput<Guid>();

            string GetFetchQuery(int pageNumber, string pagingCookie, int count)
            {
                return
                    $@"<fetch count='{count}' page='{pageNumber}' {(pageNumber > 1 ? $"paging-cookie=\"{pagingCookie}\"" : "")} latematerialize='true' no-lock='true'>
                        <entity name='ecr_penalty'>
                        <attribute name='ecr_penaltyid' />
                        <attribute name='ecr_noticeid' />
                        <attribute name='ecr_enforcementcaseid' />
                        <attribute name='statuscode' />
                        <attribute name='ecr_penaltytype' />
                        <attribute name='ecr_slafailed' />
                        <attribute name='ecr_fpnescalatetoepndate' />
                        <attribute name='ecr_hardshipcurrentinstalmentnumber' />
                        <attribute name='ecr_hardshipnextinstalmentstart' />
                        <attribute name='ecr_epnactivationdate' />
                        <attribute name='ecr_nextphonecalldate' />
                        <attribute name='ecr_due' />
                        <attribute name='ecr_epnescalationdate' />
                        <attribute name='ecr_epnhalteddate' />
                        <attribute name='ecr_progresstodebtrecoverydate' />
                        <attribute name='ecr_debtrecoverystarteddate' />
                        <attribute name='ecr_debtrecoveryphonecallcreateddate' />
                        <attribute name='ecr_debtrecoveryreminderphonecallduedate' />
                        <attribute name='ecr_debtrecoveryescalatetolegalduedate' />
                        <attribute name='ecr_debtrecoveryescalatedtolegaldate' />
                        <attribute name='ecr_hardshipescalateddate' />
                        <attribute name='ecr_epnpaused' />
                        <attribute name='ecr_debtrecoverychaseractionduedate' />
                        <attribute name='ecr_debtrecoverychaseractioncreateddate' />
                        <attribute name='ecr_debtrecoveryautomatedletterduedate' />
                        <attribute name='ecr_debtrecoveryautomatedlettercreateddate' />
                        <link-entity name='ecr_notice' to='ecr_noticeid' from='ecr_noticeid' alias='notice' link-type='inner'>
                          <attribute name='ecr_noticeid' />
                          <attribute name='ecr_enforcementcaseid' />
                          <attribute name='statuscode' />
                          <attribute name='ecr_noticetype' />
                          <attribute name='ecr_phonecallissueddate' />
                          <attribute name='ecr_issuedate' />
                          <attribute name='ecr_escalatetofpndate' />
                          <attribute name='ecr_deadline' />
                          <attribute name='ecr_epncreatedon' />
                          <link-entity name='ecr_enforcementcase' to='ecr_enforcementcaseid' from='ecr_enforcementcaseid' alias='ecase' link-type='inner'>
                            <attribute name='ecr_enforcementcaseid' />
                            <attribute name='statuscode' />
                            <attribute name='ecr_enforcementjourney' />
                            <attribute name='ecr_casetype' />
                          </link-entity>
                          <link-entity name='account' to='ecr_organisationid' from='accountid' alias='org' link-type='inner'>
                            <attribute name='accountid' />
                            <attribute name='ecr_registrationstatus' />
                            <attribute name='ecr_tprindicator' />
                            <attribute name='emailaddress1' />
                          </link-entity>
                        </link-entity>
                        <filter>
                          <condition attribute='statecode' operator='eq' value='0' />
                          <condition attribute='statecode' entityname='notice' operator='eq' value='0' />
                          <condition attribute='statecode' entityname='ecase' operator='eq' value='0' />
                          <condition attribute='statecode' entityname='org' operator='eq' value='0' />
                        </filter>
                      </entity>
                </fetch>";
            }

            int totalEntityCount = 0;
           
            MetricTimer timers = new MetricTimer(Constants.EnforcementScheduleTaskCategory,
                Constants.EnsureSchedulesPenalty, ConfigurationManager.AppSettings["APPINSIGHTS_INSTRUMENTATIONKEY"],
                ConfigurationManager.AppSettings["EnableCustomMetricCRM"],
                ConfigurationManager.AppSettings["EnableCustomMetricTable"]);
            try
            {
                int pageNumber = 1;
                string pagingCookie = null;

                while (true)
                {
                    List<BatchRecord> batchRecords = new List<BatchRecord>();
                    timers.CRMReadStart();
                    var results = crmConnection.Service.RetrieveMultiple(new FetchExpression(GetFetchQuery(pageNumber, pagingCookie, config.CRMReadPageSize)));
                    timers.CRMReadStop();
                    totalEntityCount += results.Entities.Count;
                    log.LogInformation(
                        $"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedulesPenalty - Read - Page {pageNumber} Processing {results.Entities.Count} records");
                    foreach (var entity in results.Entities)
                    {
                        try
                        {
                            var penalty = new Entity();
                            penalty.LogicalName = "ecr_penalty";
                            penalty["ecr_penaltyid"] = entity["ecr_penaltyid"];
                            penalty["ecr_noticeid"] = entity["ecr_noticeid"];
                            penalty["ecr_enforcementcaseid"] = entity["ecr_enforcementcaseid"];
                            penalty["statuscode"] = entity["statuscode"];
                            penalty["ecr_penaltytype"] = entity.Contains("ecr_penaltytype") ? entity["ecr_penaltytype"] : null;
                            penalty["ecr_slafailed"] = entity.Contains("ecr_slafailed") ? entity["ecr_slafailed"] : false;
                            penalty["ecr_fpnescalatetoepndate"] = entity.Contains("ecr_fpnescalatetoepndate") ? entity["ecr_fpnescalatetoepndate"] : null;
                            penalty["ecr_hardshipnextinstalmentstart"] = entity.Contains("ecr_hardshipnextinstalmentstart") ? entity["ecr_hardshipnextinstalmentstart"]: null;
                            penalty["ecr_epnactivationdate"] = entity.Contains("ecr_epnactivationdate") ? entity["ecr_epnactivationdate"] : null;
                            penalty["ecr_nextphonecalldate"] = entity.Contains("ecr_nextphonecalldate") ? entity["ecr_nextphonecalldate"] : null;
                            penalty["ecr_due"] = entity.Contains("ecr_due") ? entity["ecr_due"] : null;
                            penalty["ecr_epnescalationdate"] = entity.Contains("ecr_epnescalationdate") ? entity["ecr_epnescalationdate"] : null;
                            penalty["ecr_epnhalteddate"] = entity.Contains("ecr_epnhalteddate") ? entity["ecr_epnhalteddate"] : null;
                            penalty["ecr_progresstodebtrecoverydate"] = entity.Contains("ecr_progresstodebtrecoverydate") ? entity["ecr_progresstodebtrecoverydate"] : null;
                            penalty["ecr_debtrecoverystarteddate"] = entity.Contains("ecr_debtrecoverystarteddate") ? entity["ecr_debtrecoverystarteddate"] : null;
                            penalty["ecr_debtrecoveryphonecallcreateddate"]= entity.Contains("ecr_debtrecoveryphonecallcreateddate") ? entity["ecr_debtrecoveryphonecallcreateddate"] : null;
                            penalty["ecr_debtrecoveryreminderphonecallduedate"] = entity.Contains("ecr_debtrecoveryreminderphonecallduedate") ? entity["ecr_debtrecoveryreminderphonecallduedate"] : null;
                            penalty["ecr_debtrecoveryescalatetolegalduedate"] = entity.Contains("ecr_debtrecoveryescalatetolegalduedate") ? entity["ecr_debtrecoveryescalatetolegalduedate"] : null;
                            penalty["ecr_debtrecoveryescalatedtolegaldate"] = entity.Contains("ecr_debtrecoveryescalatedtolegaldate") ? entity["ecr_debtrecoveryescalatedtolegaldate"] : null;
                            penalty["ecr_hardshipescalateddate"] = entity.Contains("ecr_hardshipescalateddate") ? entity["ecr_hardshipescalateddate"] : null;
                            penalty["ecr_epnpaused"] = entity.Contains("ecr_epnpaused") ? entity["ecr_epnpaused"] : null;
                            penalty["ecr_debtrecoverychaseractionduedate"] = entity.Contains("ecr_debtrecoverychaseractionduedate") ? entity["ecr_debtrecoverychaseractionduedate"] : null;
                            penalty["ecr_debtrecoverychaseractioncreateddate"] = entity.Contains("ecr_debtrecoverychaseractioncreateddate") ? entity["ecr_debtrecoverychaseractioncreateddate"] : null;
                            penalty["ecr_debtrecoveryautomatedletterduedate"] = entity.Contains("ecr_debtrecoveryautomatedletterduedate") ? entity["ecr_debtrecoveryautomatedletterduedate"] : null;
                            penalty["ecr_debtrecoveryautomatedlettercreateddate"] = entity.Contains("ecr_debtrecoveryautomatedlettercreateddate") ? entity["ecr_debtrecoveryautomatedlettercreateddate"] : null;


                            var notice = new Entity();
                            notice.LogicalName = "ecr_notice";
                            notice.Id = entity.Contains("notice.ecr_noticeid") ? Guid.Parse(entity.GetAttributeValue<AliasedValue>("notice.ecr_noticeid").Value.ToString()): Guid.Empty;
                            notice["ecr_noticeid"] = entity.Contains("notice.ecr_noticeid") ? Guid.Parse(entity.GetAttributeValue<AliasedValue>("notice.ecr_noticeid").Value .ToString()): Guid.Empty;
                            notice["ecr_enforcementcaseid"] = entity.Contains("notice.ecr_enforcementcaseid") ? (EntityReference)entity.GetAttributeValue<AliasedValue>("notice.ecr_enforcementcaseid").Value : null;
                            notice["statuscode"] =entity.Contains("notice.statuscode") ? (OptionSetValue) entity.GetAttributeValue<AliasedValue>("notice.statuscode").Value: null ;
                            notice["ecr_noticetype"] = entity.Contains("notice.ecr_noticetype") ? (OptionSetValue) entity .GetAttributeValue<AliasedValue>("notice.ecr_noticetype").Value : null;
                            
                            if (entity.Contains("notice.ecr_epncreatedon")) notice.Attributes.Add("ecr_epncreatedon", (DateTime)entity.GetAttributeValue<AliasedValue>("notice.ecr_epncreatedon").Value);
                            else notice.Attributes.Add("ecr_epncreatedon", null);
                            
                            if (entity.Contains("notice.ecr_phonecallissueddate")) notice.Attributes.Add("ecr_phonecallissueddate", (DateTime)entity.GetAttributeValue<AliasedValue>("notice.ecr_phonecallissueddate").Value);
                            else notice.Attributes.Add("ecr_phonecallissueddate", null);
                            
                            if (entity.Contains("notice.ecr_issuedate")) notice.Attributes.Add("ecr_issuedate", (DateTime)entity.GetAttributeValue<AliasedValue>("notice.ecr_issuedate").Value);
                            else notice.Attributes.Add("ecr_issuedate", null);
                            
                            if (entity.Contains("notice.ecr_escalatetofpndate")) notice.Attributes.Add("ecr_escalatetofpndate", (DateTime)entity.GetAttributeValue<AliasedValue>("notice.ecr_escalatetofpndate").Value);
                            else notice.Attributes.Add("ecr_escalatetofpndate", null);
                            
                            if (entity.Contains("notice.ecr_deadline")) notice.Attributes.Add("ecr_deadline", (DateTime)entity.GetAttributeValue<AliasedValue>("notice.ecr_deadline").Value);
                            else notice.Attributes.Add("ecr_deadline", null);


                            var enforcementCase = new Entity();
                            enforcementCase.LogicalName = "ecr_enforcementcase";
                            enforcementCase.Id = entity.Contains("ecase.ecr_enforcementcaseid") ? Guid.Parse(entity.GetAttributeValue<AliasedValue>("ecase.ecr_enforcementcaseid").Value.ToString()): Guid.Empty;
                            enforcementCase["ecr_enforcementcaseid"] = entity.Contains("ecase.ecr_enforcementcaseid") ? Guid.Parse(entity.GetAttributeValue<AliasedValue>("ecase.ecr_enforcementcaseid").Value.ToString()): Guid.Empty;
                            enforcementCase["statuscode"] = entity.Contains("ecase.statuscode") ? (OptionSetValue) entity.GetAttributeValue<AliasedValue>("ecase.statuscode").Value : null;
                            enforcementCase["ecr_enforcementjourney"] = entity.Contains("ecase.ecr_enforcementjourney")? (OptionSetValue) entity.GetAttributeValue<AliasedValue>("ecase.ecr_enforcementjourney").Value: null;
                            enforcementCase["ecr_casetype"] = entity.Contains("ecase.ecr_casetype") ? (OptionSetValue) entity.GetAttributeValue<AliasedValue>("ecase.ecr_casetype").Value : null;


                            var account = new Entity();
                            account.LogicalName = "account";
                            account.Id = entity.Contains("org.accountid") ? Guid.Parse(entity.GetAttributeValue<AliasedValue>("org.accountid").Value.ToString()) : Guid.Empty;
                            account["accountid"] = entity.Contains("org.accountid") ? Guid.Parse(entity.GetAttributeValue<AliasedValue>("org.accountid").Value.ToString()) : Guid.Empty;
                            account["ecr_registrationstatus"] = entity.Contains("org.ecr_registrationstatus") ? (OptionSetValue) entity.GetAttributeValue<AliasedValue>("org.ecr_registrationstatus").Value : null;
                            account["ecr_tprindicator"] = entity.Contains("org.ecr_tprindicator") ? (bool) entity.GetAttributeValue<AliasedValue>("org.ecr_tprindicator").Value : false;
                            account["emailaddress1"] = entity.Contains("org.emailaddress1") ? (string) entity.GetAttributeValue<AliasedValue>("org.emailaddress1").Value : "";
                                   


                            //Casting it to Custom type to make it Serializable
                            var EnsureSchedulesPenaltyEntity = new EnsureSchedulesPenaltyEntities
                                {Penalty = penalty, Notice = notice, Account = account, EnforcementCase = enforcementCase};

                            using (var ms = new MemoryStream())
                            {
                                lateBoundSerializer.WriteObject(ms, EnsureSchedulesPenaltyEntity);
                                ms.Position = 0;

                                var reader = new StreamReader(ms);
                                var msg = reader.ReadToEnd();
                                BatchRecord batchRecord = new BatchRecord(batchId,
                                    Constants.EnforcementScheduleTaskCategory, "EnsureSchedulesPenalty", msg, null, "New",
                                    DateTime.Now, null, Guid.NewGuid().ToString(),
                                    account.Attributes["accountid"].ToString());
                                batchRecords.Add(batchRecord);
                            }

                            if (batchRecords.Count >= 50)
                            {
                                timers.TableWriteStart();
                                await storageOperations.InsertBatch(config.BatchTableName, batchRecords);
                                batchRecords.Clear();
                                timers.TableWriteStop();
                            }
                        }
                        catch (Exception e)
                        {
                            log.LogError(e.ToString());
                        }
                    }
                        

                    if (batchRecords.Count > 0)
                    {
                        timers.TableWriteStart();
                        await storageOperations.InsertBatch(config.BatchTableName, batchRecords);
                        timers.TableWriteStop();
                    }

                    log.LogInformation(
                        $"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedulesPenalty - Read - Page {pageNumber} Complete - {totalEntityCount} passed checks and stored in blob");

                    if (!results.MoreRecords)
                    {
                        break;
                    }

                    pageNumber++;
                    pagingCookie = HttpUtility.HtmlEncode(results.PagingCookie);
                }

                log.LogInformation(
                    $"{Constants.EnforcementScheduleTaskCategory} - EnsureSchedulesPenalty - Read Complete - Total Pages: {pageNumber} Total Entities Stored in Blob: {totalEntityCount} ");
            }
            catch (Exception ex)
            {
                log.LogError(ex.ToString());
            }
            timers.LogTableWrite(totalEntityCount);

            return totalEntityCount;

        }
    }
}
